https://icon-sets.iconify.design/memory/ Apache 2.0
